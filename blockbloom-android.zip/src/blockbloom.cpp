#if __has_include(<SDL2/SDL.h>)
#include <SDL2/SDL.h>
#else
#include <SDL.h>
#endif
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <fstream>
#include <functional>
#include <map>
#include <random>
#include <string>
#include <vector>

static std::string g_dir;

constexpr int LW = 1280, LH = 720, WW = 100, WH = 60, SR = 44100, MAXSLOTS = 14;
constexpr float PI2 = 6.2831853f, TREE_TIME = 45.f, PHW = 0.32f, PH = 1.45f;
constexpr int ZOOM[4] = {24, 32, 40, 48};
constexpr int RES[3][2] = {{1280, 720}, {1600, 900}, {1920, 1080}};
#ifdef __ANDROID__
constexpr int AUDIO_SAMPLES = 2048;
#else
constexpr int AUDIO_SAMPLES = 1024;
#endif

enum Tid : uint8_t { T_AIR, T_DIRT, T_GRASS, T_ROCK, T_BEDROCK, T_LAVA, T_WOOD, T_GLASS, T_DOOR, T_TREE, T_COUNT };
static const int HARD[T_COUNT] = {0, 3, 3, 6, 0, 3, 4, 2, 0, 1};
static const int TCOL[T_COUNT][3] = {{0, 0, 0}, {120, 80, 45}, {100, 150, 60}, {125, 125, 135}, {50, 50, 60},
                                     {240, 110, 20}, {175, 125, 65}, {170, 225, 250}, {240, 240, 245}, {70, 150, 60}};
static const char* TNAME[T_COUNT] = {"AIR", "DIRT", "GRASS", "ROCK", "BEDROCK", "LAVA", "WOOD BLOCK", "GLASS", "DOOR", "TREE"};

static const char* GCH = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789:.-/<>!?+,()_ %";
static const char* GR[] = {"25755", "65656", "34443", "65556", "74647", "74644", "34553", "55755", "72227", "11152",
                           "55655", "44447", "57755", "65555", "25552", "65644", "25573", "65655", "34216", "72222",
                           "55557", "55552", "55775", "55255", "55222", "71247", "75557", "26227", "61247", "61216",
                           "55711", "74616", "34757", "71222", "75757", "75716", "02020", "00002", "00700", "11244",
                           "12421", "42124", "22202", "61202", "02720", "00024", "12221", "42224", "00007", "00000",
                           "51245"};

static uint32_t hash32(uint32_t a) {
    a ^= a >> 16; a *= 0x7feb352dU; a ^= a >> 15; a *= 0x846ca68bU; a ^= a >> 16;
    return a;
}
static uint32_t hash2(int x, int y, int s = 0) {
    return hash32(hash32((uint32_t)x * 73856093U ^ (uint32_t)y * 19349663U) + (uint32_t)s * 83492791U);
}
static float nz() {
    static uint32_t s = 2463534242u;
    s ^= s << 13; s ^= s >> 17; s ^= s << 5;
    return (s & 0xFFFF) / 32768.f - 1.f;
}
static float frand() { return (nz() + 1.f) * 0.5f; }
static int clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }
static float mtof(float m) { return 440.f * std::pow(2.f, (m - 69.f) / 12.f); }
static std::string upper(std::string s) {
    for (auto& c : s) c = (char)std::toupper((unsigned char)c);
    return s;
}

struct Settings {
    int master = 80, sfx = 80, music = 45, shake = 1, chat = 1, fullscreen = 0, vsync = 1, fpsLimit = 1, res = 0,
#ifdef __ANDROID__
        zoom = 2,
#else
        zoom = 1,
#endif
        particles = 1, clouds = 1, showFps = 0;
    std::vector<int*> all() {
        return {&master, &sfx, &music, &shake, &chat, &fullscreen, &vsync, &fpsLimit, &res, &zoom, &particles, &clouds, &showFps};
    }
    void fix() {
        master = clampi(master, 0, 100); sfx = clampi(sfx, 0, 100); music = clampi(music, 0, 100);
        shake = clampi(shake, 0, 1); chat = clampi(chat, 0, 1); fullscreen = clampi(fullscreen, 0, 1);
        vsync = clampi(vsync, 0, 1); fpsLimit = clampi(fpsLimit, 0, 3); res = clampi(res, 0, 2);
        zoom = clampi(zoom, 0, 3); particles = clampi(particles, 0, 1); clouds = clampi(clouds, 0, 1);
        showFps = clampi(showFps, 0, 1);
    }
    void load() {
        std::ifstream f(g_dir + "settings.cfg");
        if (!f) return;
        for (int* p : all()) {
            int v;
            if (f >> v) *p = v;
        }
        fix();
    }
    void save() {
        std::ofstream f(g_dir + "settings.cfg");
        for (int* p : all()) f << *p << "\n";
    }
};

enum Snd { S_CLICK, S_PUNCH, S_BREAK, S_PLACE, S_JUMP, S_LAND, S_GEM, S_PICK, S_PLANT, S_HARVEST, S_DEATH, S_ENTER, S_CHAT, S_DENY, S_MUSIC, S_N };

struct Voice {
    const std::vector<int16_t>* buf = nullptr;
    float pos = 0, rate = 1, vol = 0;
    bool loop = false, music = false, active = false;
};

static std::vector<int16_t> synth(float dur, const std::function<float(float, float)>& f) {
    int n = (int)(dur * SR);
    std::vector<int16_t> v(n);
    for (int i = 0; i < n; i++) {
        float t = i / (float)SR;
        float s = f(t, t / dur);
        s = std::max(-1.f, std::min(1.f, s));
        v[i] = (int16_t)(s * 30000);
    }
    return v;
}

struct Audio {
    SDL_AudioDeviceID dev = 0;
    Settings* S = nullptr;
    std::vector<int16_t> bank[S_N];
    Voice v[24];
    std::vector<float> mix = std::vector<float>(16384, 0.f);

    static void cb(void* ud, Uint8* st, int len) {
        Audio* a = (Audio*)ud;
        int n = len / 2;
        if (n > (int)a->mix.size()) n = (int)a->mix.size();
        std::fill(a->mix.begin(), a->mix.begin() + n, 0.f);
        float mv = a->S->master / 100.f;
        for (auto& vo : a->v) {
            if (!vo.active) continue;
            const auto& b = *vo.buf;
            float g = vo.music ? a->S->music / 100.f * mv * 0.8f : vo.vol * mv;
            for (int i = 0; i < n; i++) {
                size_t ip = (size_t)vo.pos;
                if (ip + 1 >= b.size()) {
                    if (vo.loop) {
                        vo.pos -= (float)b.size();
                        if (vo.pos < 0) vo.pos = 0;
                        ip = (size_t)vo.pos;
                    } else {
                        vo.active = false;
                        break;
                    }
                }
                float fr = vo.pos - (float)ip;
                float s = b[ip] * (1.f - fr) + b[ip + 1] * fr;
                a->mix[i] += s / 32768.f * g;
                vo.pos += vo.rate;
            }
        }
        int16_t* o = (int16_t*)st;
        for (int i = 0; i < n; i++) {
            float s = std::max(-1.f, std::min(1.f, a->mix[i]));
            o[i] = (int16_t)(s * 32000);
        }
        for (int i = n; i < len / 2; i++) o[i] = 0;
    }

    bool open(Settings* s) {
        S = s;
        SDL_AudioSpec w{}, h{};
        w.freq = SR; w.format = AUDIO_S16SYS; w.channels = 1; w.samples = AUDIO_SAMPLES; w.callback = cb; w.userdata = this;
        dev = SDL_OpenAudioDevice(nullptr, 0, &w, &h, 0);
        if (!dev) return false;
        SDL_PauseAudioDevice(dev, 0);
        return true;
    }

    void play(int id, float vol = 1.f, float rate = 1.f, bool loop = false, bool music = false) {
        if (!dev || bank[id].size() < 2) return;
        SDL_LockAudioDevice(dev);
        int slot = 0;
        if (music) slot = 23;
        else {
            bool found = false;
            for (int i = 0; i < 23; i++)
                if (!v[i].active) { slot = i; found = true; break; }
            if (!found) slot = 0;
        }
        Voice& x = v[slot];
        x.buf = &bank[id]; x.pos = 0; x.rate = rate; x.vol = vol * S->sfx / 100.f; x.loop = loop; x.music = music; x.active = true;
        SDL_UnlockAudioDevice(dev);
    }

    void genMusic() {
        const float bpm = 96.f;
        int step = (int)(SR * 60.f / bpm / 2.f), steps = 32, N = step * steps;
        std::vector<float> b(N, 0.f);
        static const int mel[32] = {0, 4, 7, 4, 9, 7, 4, 2, 0, 4, 7, 12, 9, 7, 4, 2, 2, 5, 9, 5, 7, 4, 2, 0, 4, 7, 9, 12, 9, 7, 4, -100};
        static const int bass[4] = {36, 33, 41, 43};
        for (int s = 0; s < steps; s++) {
            if (mel[s] > -50) {
                float f = mtof(60.f + mel[s]);
                int len = std::min(step * 3, N);
                for (int j = 0; j < len; j++) {
                    float t = j / (float)SR;
                    float env = std::exp(-t * 4.f) * std::min(1.f, t * 90.f);
                    b[(s * step + j) % N] += (std::sin(PI2 * f * t) + 0.3f * std::sin(PI2 * 2 * f * t)) * env * 0.16f;
                }
            }
            if (s % 8 == 0) {
                float f = mtof((float)bass[s / 8]);
                int len = step * 8;
                for (int j = 0; j < len; j++) {
                    float t = j / (float)SR;
                    float env = std::min(1.f, t * 30.f) * std::min(1.f, (len - j) / (SR * 0.05f));
                    b[(s * step + j) % N] += std::sin(PI2 * f * t) * env * 0.22f;
                }
            }
        }
        int D = (int)(SR * 0.234f);
        bank[S_MUSIC].assign(N, 0);
        for (int i = 0; i < N; i++) {
            float o = b[i] + 0.28f * b[(i - D + N) % N] + 0.14f * b[(i - 2 * D + 2 * N) % N];
            o = std::max(-1.f, std::min(1.f, o * 0.9f));
            bank[S_MUSIC][i] = (int16_t)(o * 30000);
        }
    }

    void gen(int id) {
        switch (id) {
            case S_CLICK:
                bank[id] = synth(0.07f, [](float t, float) { return std::sin(PI2 * 1000 * t) * std::exp(-t * 55) * 0.6f; });
                break;
            case S_PUNCH:
                bank[id] = synth(0.14f, [ph = 0.f, lp = 0.f](float t, float) mutable {
                    ph += PI2 * (170.f * std::exp(-t * 14) + 60.f) / SR;
                    lp += 0.3f * (nz() - lp);
                    return std::sin(ph) * std::exp(-t * 20) * 0.9f + lp * std::exp(-t * 35) * 0.8f;
                });
                break;
            case S_BREAK:
                bank[id] = synth(0.3f, [ph = 0.f, lp = 0.f](float t, float) mutable {
                    ph += PI2 * (110.f * std::exp(-t * 6) + 50.f) / SR;
                    lp += 0.25f * (nz() - lp);
                    return lp * std::exp(-t * 9) * 1.7f + std::sin(ph) * std::exp(-t * 14) * 0.6f;
                });
                break;
            case S_PLACE:
                bank[id] = synth(0.12f, [ph = 0.f](float t, float) mutable {
                    ph += PI2 * (520.f * std::exp(-t * 10) + 160.f) / SR;
                    return std::sin(ph) * std::exp(-t * 28) * 0.8f + nz() * std::exp(-t * 90) * 0.2f;
                });
                break;
            case S_JUMP:
                bank[id] = synth(0.2f, [ph = 0.f](float, float p) mutable {
                    ph += PI2 * (240.f + 400.f * p) / SR;
                    return (0.3f * std::sin(ph) + 0.15f * (std::sin(ph) > 0 ? 1.f : -1.f)) * (1.f - p);
                });
                break;
            case S_LAND:
                bank[id] = synth(0.09f, [ph = 0.f](float t, float) mutable {
                    ph += PI2 * (90.f * std::exp(-t * 20) + 50.f) / SR;
                    return std::sin(ph) * std::exp(-t * 35) * 0.9f;
                });
                break;
            case S_GEM:
                bank[id] = synth(0.16f, [](float t, float) {
                    float f = t < 0.07f ? 1318.5f : 1760.f;
                    float lt = t < 0.07f ? t : t - 0.07f;
                    return std::sin(PI2 * f * t) * std::exp(-lt * 30) * 0.5f;
                });
                break;
            case S_PICK:
                bank[id] = synth(0.1f, [ph = 0.f](float t, float p) mutable {
                    ph += PI2 * (900.f + 700.f * p) / SR;
                    return std::sin(ph) * std::exp(-t * 25) * 0.6f;
                });
                break;
            case S_PLANT:
                bank[id] = synth(0.18f, [lp = 0.f](float t, float) mutable {
                    lp += 0.2f * (nz() - lp);
                    return lp * std::exp(-t * 18) * 1.2f + std::sin(PI2 * 280 * t) * std::exp(-t * 25) * 0.5f;
                });
                break;
            case S_HARVEST:
                bank[id] = synth(0.42f, [](float t, float) {
                    static const float fr[4] = {523.f, 659.f, 784.f, 1047.f};
                    int i = std::min(3, (int)(t / 0.1f));
                    return std::sin(PI2 * fr[i] * t) * std::exp(-(t - i * 0.1f) * 12) * 0.5f;
                });
                break;
            case S_DEATH:
                bank[id] = synth(0.6f, [ph = 0.f](float t, float p) mutable {
                    ph += PI2 * (420.f * std::exp(-t * 3.5f) + 50.f) / SR;
                    float saw = 2.f * (ph / PI2 - std::floor(ph / PI2)) - 1.f;
                    return saw * 0.5f * (1.f - p);
                });
                break;
            case S_ENTER:
                bank[id] = synth(0.6f, [](float t, float) {
                    float e = std::exp(-t * 5) * std::min(1.f, t * 40);
                    return (std::sin(PI2 * 523.f * t) + std::sin(PI2 * 659.f * t) + std::sin(PI2 * 784.f * t)) * e * 0.28f;
                });
                break;
            case S_CHAT:
                bank[id] = synth(0.14f, [](float t, float) {
                    float f = t < 0.06f ? 800.f : 1100.f;
                    float lt = t < 0.06f ? t : t - 0.06f;
                    return std::sin(PI2 * f * t) * std::exp(-lt * 30) * 0.5f;
                });
                break;
            case S_DENY:
                bank[id] = synth(0.14f, [](float t, float p) {
                    return (std::sin(PI2 * 110 * t) > 0 ? 1.f : -1.f) * 0.3f * (1.f - p);
                });
                break;
            case S_MUSIC: genMusic(); break;
        }
    }
};

static void shade(int type, int v, int x, int y, int& r, int& g, int& b, int& a) {
    uint32_t h = hash2(x + v * 16, y, type * 31 + 7);
    int n = (int)(h % 100);
    a = 255;
    auto dirt = [&]() {
        r = 120; g = 80; b = 45;
        if (n < 18) { r -= 25; g -= 18; b -= 12; }
        else if (n > 90) { r += 25; g += 20; b += 12; }
    };
    switch (type) {
        case T_DIRT: dirt(); break;
        case T_GRASS:
            if (y < 4 + (int)(hash2(x, 0, v) % 2)) {
                r = 95; g = 165; b = 55;
                if (n < 25) { r -= 20; g -= 25; b -= 10; }
            } else dirt();
            break;
        case T_ROCK:
            r = 125; g = 125; b = 135;
            if (n < 20) { r -= 30; g -= 30; b -= 30; }
            else if (n > 88) { r += 20; g += 20; b += 20; }
            if (x == 0 || y == 0) { r += 20; g += 20; b += 20; }
            if (x == 15 || y == 15) { r -= 25; g -= 25; b -= 25; }
            if ((x + y * 2 + v * 5) % 13 == 0 && n < 60) { r -= 35; g -= 35; b -= 35; }
            break;
        case T_BEDROCK:
            r = 50; g = 50; b = 60;
            if (((x / 4) + (y / 4)) % 2 == 0) { r += 10; g += 10; b += 10; }
            if (n < 15) { r += 22; g += 22; b += 22; }
            else if (n > 90) { r -= 15; g -= 15; b -= 15; }
            break;
        case T_LAVA: {
            int k = (int)(40 * std::sin(x * 0.6f + v * 1.57f) + 40 * std::cos(y * 0.7f - v * 1.57f));
            r = 235 + (k > 40 ? 20 : 0); g = 90 + k; b = 15;
            break;
        }
        case T_WOOD:
            r = 175; g = 125; b = 65;
            if (y % 5 == 4) { r -= 45; g -= 45; b -= 30; }
            if (((y / 5) % 2 == 0 && x == 7) || ((y / 5) % 2 == 1 && x == 0)) { r -= 35; g -= 35; b -= 25; }
            if (n < 12) { r -= 15; g -= 15; b -= 10; }
            break;
        case T_GLASS:
            r = 175; g = 225; b = 250; a = 90;
            if (x == 0 || y == 0 || x == 15 || y == 15) { r = 235; g = 248; b = 255; a = 200; }
            if ((x + y == 5 || x + y == 6 || x + y == 10) && x > 1 && x < 14 && y > 1 && y < 14) { r = g = b = 255; a = 200; }
            break;
        case T_DOOR:
            if (x < 2 || x > 13 || y < 1) { r = 240; g = 240; b = 245; }
            else if (x < 4 || x > 11 || y < 3) { r = 200; g = 200; b = 210; }
            else { r = 70; g = 100; b = 210; }
            if (x == 10 && y == 9) { r = 255; g = 210; b = 60; }
            break;
        case T_COUNT:
            r = 70; g = 48; b = 36;
            if (n < 20) { r = 55; g = 38; b = 28; }
            else if (n > 92) { r = 85; g = 60; b = 45; }
            break;
        default: r = g = b = 0; a = 0; break;
    }
    r = clampi(r, 0, 255); g = clampi(g, 0, 255); b = clampi(b, 0, 255);
}

static SDL_Texture* makeTiles(SDL_Renderer* ren) {
    int rows = T_COUNT + 1;
    SDL_Surface* sf = SDL_CreateRGBSurfaceWithFormat(0, 4 * 16, rows * 16, 32, SDL_PIXELFORMAT_RGBA32);
    Uint32* px = (Uint32*)sf->pixels;
    int pitch = sf->pitch / 4;
    for (int t = 1; t <= T_COUNT; t++)
        for (int v = 0; v < 4; v++)
            for (int y = 0; y < 16; y++)
                for (int x = 0; x < 16; x++) {
                    int r, g, b, a;
                    shade(t, v, x, y, r, g, b, a);
                    px[(t * 16 + y) * pitch + v * 16 + x] = SDL_MapRGBA(sf->format, r, g, b, a);
                }
    SDL_Texture* tex = SDL_CreateTextureFromSurface(ren, sf);
    SDL_SetTextureBlendMode(tex, SDL_BLENDMODE_BLEND);
    SDL_FreeSurface(sf);
    return tex;
}

struct Tile {
    uint8_t fg = 0, tree = 0, dmg = 0;
    float age = 0, dmgT = 0;
};

struct World {
    std::string name;
    std::vector<Tile> t = std::vector<Tile>(WW * WH);
    std::vector<int> surf = std::vector<int>(WW);
    int doorX = WW / 2, doorY = 0;

    Tile& at(int x, int y) { return t[y * WW + x]; }
    bool in(int x, int y) const { return x >= 0 && x < WW && y >= 0 && y < WH; }

    void generate(const std::string& n) {
        name = n;
        uint32_t seed = 7;
        for (char c : n) seed = seed * 131u + (uint8_t)c;
        std::mt19937 rg(seed);
        float p1 = (rg() % 628) / 100.f, p2 = (rg() % 628) / 100.f, p3 = (rg() % 628) / 100.f;
        for (int x = 0; x < WW; x++) {
            float h = 22 + 3.f * std::sin(x * .13f + p1) + 2.f * std::sin(x * .31f + p2) + 1.5f * std::sin(x * .05f + p3);
            surf[x] = (int)h;
        }
        int base = surf[doorX];
        for (int dx = -3; dx <= 3; dx++) surf[doorX + dx] = base;
        for (int y = 0; y < WH; y++)
            for (int x = 0; x < WW; x++) {
                Tile& tl = at(x, y);
                tl = Tile();
                int s = surf[x];
                uint8_t f = T_AIR;
                if (y >= WH - 2) f = T_BEDROCK;
                else if (y == WH - 3) f = (hash2(x, y, (int)seed) % 3 == 0) ? T_ROCK : T_BEDROCK;
                else if (y < s) f = T_AIR;
                else if (y == s) f = T_GRASS;
                else if (y <= s + 3) f = T_DIRT;
                else {
                    f = T_ROCK;
                    if (hash2(x / 3, y / 3, (int)seed) % 100 < 16) f = T_DIRT;
                    if (y > s + 14 && y < WH - 4 && hash2(x / 2, y / 2, (int)seed + 7) % 100 < 5) f = T_LAVA;
                    float cn = std::sin(x * .2f + p1) * std::sin(y * .25f + p2) + std::sin(x * .11f + y * .13f + p3);
                    if (cn > 1.3f && y > s + 5 && y < WH - 5) f = T_AIR;
                }
                tl.fg = f;
            }
        doorY = surf[doorX] - 1;
        at(doorX, doorY + 1).fg = T_BEDROCK;
        at(doorX, doorY).fg = T_DOOR;
    }

    bool save() const {
        std::ofstream f(g_dir + "world_" + name + ".bbw", std::ios::binary);
        if (!f) return false;
        uint32_t m = 0x31574242u;
        f.write((const char*)&m, 4);
        int dims[4] = {WW, WH, doorX, doorY};
        f.write((const char*)dims, sizeof dims);
        f.write((const char*)surf.data(), WW * sizeof(int));
        for (const Tile& q : t) {
            f.put((char)q.fg);
            f.put((char)q.tree);
            f.write((const char*)&q.age, 4);
        }
        return (bool)f;
    }

    bool load(const std::string& n) {
        std::ifstream f(g_dir + "world_" + n + ".bbw", std::ios::binary);
        if (!f) return false;
        uint32_t m = 0;
        f.read((char*)&m, 4);
        int dims[4];
        f.read((char*)dims, sizeof dims);
        if (!f || m != 0x31574242u || dims[0] != WW || dims[1] != WH) return false;
        f.read((char*)surf.data(), WW * sizeof(int));
        for (Tile& q : t) {
            char a = 0, b = 0;
            f.get(a); f.get(b);
            f.read((char*)&q.age, 4);
            q.fg = (uint8_t)a; q.tree = (uint8_t)b; q.dmg = 0; q.dmgT = 0;
        }
        if (!f) return false;
        name = n; doorX = dims[2]; doorY = dims[3];
        return true;
    }
};

struct MItem {
    std::string label;
    int kind = 0;
    int* v = nullptr;
    int lo = 0, hi = 1;
    std::vector<std::string> opts;
    std::function<void()> act;
};
struct Menu {
    std::vector<MItem> items;
    int sel = 0;
    std::string title;
};

struct Slot { int id = 0, count = 0; };
struct Drop { float x, y, vx, vy, age; int item, count; };
struct Part { float x, y, vx, vy, life, max, size; int r, g, b; };
struct FText { float x, y, life; std::string s; int r, g, b; };
struct ChatLine { std::string s; float life; };
struct Cloud { float x, y, s, sp; };
struct Player {
    float x = 0, y = 0, vx = 0, vy = 0, punchT = 0, coyote = 0, jumpBuf = 0, walkT = 0, bubbleT = 0;
    bool ground = false, jumpHeld = false;
    int face = 1;
    std::string bubble;
};

enum State { ST_LOADING, ST_MENU, ST_SETTINGS, ST_GRAPHICS, ST_WORLD, ST_PLAY, ST_PAUSE };

struct Game {
    SDL_Window* win = nullptr;
    SDL_Renderer* ren = nullptr;
    SDL_Texture* tiles = nullptr;
    Settings S;
    Audio au;
    State st = ST_LOADING, from = ST_MENU;
    bool running = true, mdown = false, mdownWorld = false, chatOpen = false, musicOn = false;
    int mx = 0, my = 0, drag = -1;
    double time = 0;
    float fps = 60, loadT = 0, camX = 0, camY = 0, shake = 0, flash = 0, actCd = 0, autosave = 0, tipT = 0;
    int ccx = 0, ccy = 0, sel = 0, gems = 0;
    Menu mMain, mSet, mGfx, mPause;
    std::vector<std::function<void()>> tasks;
    size_t taskI = 0;
    std::vector<Cloud> clouds;
    World w;
    Player p;
    std::vector<Slot> inv;
    std::vector<Drop> drops;
    std::vector<Part> parts;
    std::vector<FText> ftexts;
    std::vector<ChatLine> chatLog;
    std::string wname = "START", chatBuf;
    bool touch = false, hasAct = false;
    int tmx = 0, tmy = 0;
    SDL_FingerID actFinger = 0;
    std::map<SDL_FingerID, int> fingers;

    bool init() {
        if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) != 0) return false;
        char* pp = SDL_GetPrefPath("Faddlan", "Blockbloom");
        if (pp) { g_dir = pp; SDL_free(pp); }
        S.load();
        SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "0");
        SDL_SetHint(SDL_HINT_ORIENTATIONS, "LandscapeLeft LandscapeRight");
#ifdef __ANDROID__
        touch = true;
        Uint32 wf = SDL_WINDOW_FULLSCREEN;
#else
        Uint32 wf = SDL_WINDOW_RESIZABLE | (S.fullscreen ? SDL_WINDOW_FULLSCREEN_DESKTOP : 0);
#endif
        win = SDL_CreateWindow("Blockbloom", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, RES[S.res][0], RES[S.res][1], wf);
        if (!win) return false;
        ren = SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED | (S.vsync ? SDL_RENDERER_PRESENTVSYNC : 0));
        if (!ren) ren = SDL_CreateRenderer(win, -1, 0);
        if (!ren) return false;
        SDL_RenderSetLogicalSize(ren, LW, LH);
        SDL_SetRenderDrawBlendMode(ren, SDL_BLENDMODE_BLEND);
        for (int i = 0; i < 7; i++) clouds.push_back({i * 230.f, 40.f + (i * 53) % 220, 0.8f + (i % 3) * 0.3f, 6.f + i * 2.f});
        tasks.push_back([this] { au.open(&S); });
        for (int i = 0; i < S_MUSIC; i++) tasks.push_back([this, i] { au.gen(i); });
        tasks.push_back([this] { au.gen(S_MUSIC); });
        tasks.push_back([this] { tiles = makeTiles(ren); });
        buildMenus();
        return true;
    }

    void applyGraphics() {
#ifndef __ANDROID__
        if (S.fullscreen) SDL_SetWindowFullscreen(win, SDL_WINDOW_FULLSCREEN_DESKTOP);
        else {
            SDL_SetWindowFullscreen(win, 0);
            SDL_SetWindowSize(win, RES[S.res][0], RES[S.res][1]);
            SDL_SetWindowPosition(win, SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED);
        }
#endif
#if SDL_VERSION_ATLEAST(2, 0, 18)
        SDL_RenderSetVSync(ren, S.vsync);
#endif
    }

    void buildMenus() {
        auto btn = [](const char* l, std::function<void()> a) {
            MItem m; m.label = l; m.kind = 0; m.act = a;
            return m;
        };
        auto sld = [this](const char* l, int* v) {
            MItem m; m.label = l; m.kind = 1; m.v = v; m.lo = 0; m.hi = 100;
            m.act = [this] { au.play(S_CLICK, 0.5f); };
            return m;
        };
        auto tog = [](const char* l, int* v, std::function<void()> a) {
            MItem m; m.label = l; m.kind = 2; m.v = v; m.lo = 0; m.hi = 1; m.act = a;
            return m;
        };
        auto cho = [](const char* l, int* v, std::vector<std::string> o, std::function<void()> a) {
            MItem m; m.label = l; m.kind = 3; m.v = v; m.lo = 0; m.hi = (int)o.size() - 1; m.opts = o; m.act = a;
            return m;
        };
        auto gfx = [this] { applyGraphics(); };
        auto none = [] {};
        auto toSettings = [this] { from = st; st = ST_SETTINGS; mSet.sel = 0; };
        auto toGfx = [this] { from = st; st = ST_GRAPHICS; mGfx.sel = 0; };
        auto back = [this] { S.save(); st = from; };

        mMain.items = {btn("PLAY", [this] { st = ST_WORLD; SDL_StartTextInput(); }),
                       btn("SETTINGS", toSettings), btn("GRAPHICS", toGfx), btn("QUIT", [this] { quit(); })};
        mSet.title = "SETTINGS";
        mSet.items = {sld("MASTER VOLUME", &S.master), sld("SOUND EFFECTS", &S.sfx), sld("MUSIC", &S.music),
                      tog("SCREEN SHAKE", &S.shake, none), tog("CHAT BUBBLES", &S.chat, none), btn("BACK", back)};
        mGfx.title = "GRAPHICS";
        mGfx.items = {tog("FULLSCREEN", &S.fullscreen, gfx),
                      cho("RESOLUTION", &S.res, {"1280X720", "1600X900", "1920X1080"}, gfx),
                      tog("VSYNC", &S.vsync, gfx),
                      cho("FPS LIMIT", &S.fpsLimit, {"30", "60", "120", "UNLIMITED"}, none),
                      cho("ZOOM", &S.zoom, {"SMALL", "NORMAL", "LARGE", "HUGE"}, none),
                      tog("PARTICLES", &S.particles, none), tog("CLOUDS", &S.clouds, none),
                      tog("SHOW FPS", &S.showFps, none), btn("BACK", back)};
#ifdef __ANDROID__
        mGfx.items.erase(mGfx.items.begin(), mGfx.items.begin() + 2);
#endif
        mPause.title = "PAUSED";
        mPause.items = {btn("RESUME", [this] { st = ST_PLAY; }), btn("SETTINGS", toSettings), btn("GRAPHICS", toGfx),
                        btn("EXIT WORLD", [this] { saveAll(); st = ST_MENU; })};
    }

    void quit() {
        if (st == ST_PLAY || st == ST_PAUSE) saveAll();
        S.save();
        running = false;
    }

    void saveAll() {
        w.save();
        std::ofstream f(g_dir + "player.dat", std::ios::binary);
        int n = (int)inv.size();
        f.write((const char*)&gems, 4);
        f.write((const char*)&n, 4);
        for (auto& s : inv) {
            f.write((const char*)&s.id, 4);
            f.write((const char*)&s.count, 4);
        }
    }

    void loadPlayer() {
        inv.clear(); gems = 0;
        std::ifstream f(g_dir + "player.dat", std::ios::binary);
        int n = 0;
        if (f) {
            f.read((char*)&gems, 4);
            f.read((char*)&n, 4);
            if (!f || n < 0 || n > MAXSLOTS) { n = 0; gems = 0; }
            for (int i = 0; i < n; i++) {
                Slot s;
                f.read((char*)&s.id, 4);
                f.read((char*)&s.count, 4);
                if (f) inv.push_back(s);
            }
        }
        if (inv.empty() || inv[0].id != 0) {
            inv.clear();
            inv.push_back({0, 1});
            inv.push_back({T_DIRT, 30});
            inv.push_back({T_WOOD, 12});
            inv.push_back({T_GLASS, 12});
            inv.push_back({T_ROCK, 12});
            inv.push_back({100 + T_DIRT, 3});
        }
        sel = 0;
    }

    void enterWorld(std::string name) {
        name = upper(name);
        if (name.empty()) return;
        if (!w.load(name)) {
            w = World();
            w.generate(name);
        }
        wname = name;
        loadPlayer();
        drops.clear(); parts.clear(); ftexts.clear(); chatLog.clear();
        p = Player();
        p.x = w.doorX + 0.5f; p.y = w.doorY + 1.f - 0.001f;
        camX = p.x * ZOOM[S.zoom] - LW / 2.f; camY = (p.y - 0.7f) * ZOOM[S.zoom] - LH / 2.f;
        clampCam();
        chatOpen = false; chatBuf.clear(); clearTouch(); autosave = 0; flash = 0;
        SDL_StopTextInput();
        say("WELCOME TO " + name + "!");
        say("PRESS ENTER TO CHAT. PUNCH BLOCKS WITH YOUR FIST.");
        spawnText(p.x, p.y - 1.8f, "WELCOME!", 255, 230, 120);
        au.play(S_ENTER, 0.8f);
        st = ST_PLAY;
    }

    void clampCam() {
        int tp = ZOOM[S.zoom];
        camX = std::max(0.f, std::min(camX, (float)(WW * tp - LW)));
        camY = std::max(0.f, std::min(camY, (float)(WH * tp - LH)));
    }

    void clearTouch() { fingers.clear(); hasAct = false; mdownWorld = false; }
    bool heldRole(int r) { for (auto& f : fingers) if (f.second == r) return true; return false; }
    SDL_Rect btnRect(int i) {
        static const SDL_Rect R[5] = {{30, 500, 120, 120}, {170, 500, 120, 120}, {1130, 500, 120, 120}, {1110, 12, 76, 48}, {1194, 12, 74, 48}};
        return R[i];
    }
    void fingerPos(const SDL_TouchFingerEvent& f, int& lx, int& ly) {
        int ww = 1, wh = 1;
        SDL_GetWindowSize(win, &ww, &wh);
        float sc = std::min(ww / (float)LW, wh / (float)LH);
        float ox = (ww - LW * sc) / 2.f, oy = (wh - LH * sc) / 2.f;
        lx = (int)((f.x * ww - ox) / sc);
        ly = (int)((f.y * wh - oy) / sc);
    }

    void say(const std::string& s) { chatLog.push_back({s, 9.f}); if (chatLog.size() > 8) chatLog.erase(chatLog.begin()); }
    void spawnText(float x, float y, const std::string& s, int r, int g, int b) { ftexts.push_back({x, y, 1.4f, s, r, g, b}); }

    void burst(float x, float y, int r, int g, int b, int n, float spd) {
        if (!S.particles) return;
        for (int i = 0; i < n; i++)
            parts.push_back({x, y, nz() * spd, -frand() * spd * 1.2f, 0.5f + frand() * 0.3f, 0.8f, 0.08f + frand() * 0.08f, r, g, b});
    }

    bool solid(int x, int y) {
        if (x < 0 || x >= WW || y < 0 || y >= WH) return true;
        uint8_t f = w.t[y * WW + x].fg;
        return f == T_DIRT || f == T_GRASS || f == T_ROCK || f == T_BEDROCK || f == T_WOOD || f == T_GLASS;
    }

    bool hit(float x, float y) {
        int x0 = (int)std::floor(x - PHW), x1 = (int)std::floor(x + PHW - 0.0001f);
        int y0 = (int)std::floor(y - PH), y1 = (int)std::floor(y - 0.0001f);
        for (int ty = y0; ty <= y1; ty++)
            for (int tx = x0; tx <= x1; tx++)
                if (solid(tx, ty)) return true;
        return false;
    }

    void movePlayer(float dt) {
        p.x += p.vx * dt;
        if (hit(p.x, p.y)) {
            if (p.vx > 0) p.x = std::floor(p.x + PHW) - PHW - 0.001f;
            else if (p.vx < 0) p.x = std::floor(p.x - PHW) + 1.f + PHW + 0.001f;
            p.vx = 0;
        }
        p.ground = false;
        p.y += p.vy * dt;
        if (hit(p.x, p.y)) {
            if (p.vy > 0) { p.y = std::floor(p.y) - 0.001f; p.ground = true; }
            else if (p.vy < 0) p.y = std::floor(p.y - PH) + 1.f + PH + 0.001f;
            p.vy = 0;
        }
    }

    void die() {
        au.play(S_DEATH, 0.9f);
        burst(p.x, p.y - 0.7f, 240, 100, 20, 24, 6.f);
        say("YOU WERE KILLED BY LAVA!");
        flash = 1.f;
        p.x = w.doorX + 0.5f; p.y = w.doorY + 1.f - 0.001f; p.vx = p.vy = 0;
        spawnText(p.x, p.y - 1.8f, "RESPAWNED", 255, 120, 100);
    }

    void addItem(int id, int n) {
        for (auto& s : inv)
            if (s.id == id) { s.count = std::min(200, s.count + n); return; }
        if ((int)inv.size() < MAXSLOTS) inv.push_back({id, n});
    }

    bool canAdd(int id) {
        for (auto& s : inv)
            if (s.id == id) return s.count < 200;
        return (int)inv.size() < MAXSLOTS;
    }

    void useOne() {
        inv[sel].count--;
        if (inv[sel].count <= 0 && sel > 0) {
            inv.erase(inv.begin() + sel);
            if (sel >= (int)inv.size()) sel = (int)inv.size() - 1;
        }
    }

    void dropItem(float x, float y, int item, int count) {
        drops.push_back({x, y, nz() * 2.5f, -3.f - frand() * 2.f, 0.f, item, count});
    }

    void breakBlock(int tx, int ty) {
        Tile& t = w.at(tx, ty);
        int type = t.fg;
        t.fg = T_AIR; t.dmg = 0; t.tree = 0;
        au.play(S_BREAK, 0.9f, 0.92f + frand() * 0.16f);
        burst(tx + 0.5f, ty + 0.5f, TCOL[type][0], TCOL[type][1], TCOL[type][2], 12, 4.f);
        if (S.shake) shake = 0.18f;
        int base = type == T_GRASS ? T_DIRT : type;
        if (type != T_LAVA) {
            if (frand() < 0.35f) dropItem(tx + 0.5f, ty + 0.5f, base, 1);
            if (frand() < 0.14f) dropItem(tx + 0.5f, ty + 0.5f, 100 + base, 1);
        }
        if (frand() < 0.55f) dropItem(tx + 0.5f, ty + 0.5f, -1, 1 + (int)(frand() * 3));
        if (w.in(tx, ty - 1) && w.at(tx, ty - 1).fg == T_TREE) {
            Tile& tr = w.at(tx, ty - 1);
            dropItem(tx + 0.5f, ty - 0.5f, 100 + tr.tree, 1);
            tr.fg = T_AIR; tr.tree = 0; tr.age = 0;
        }
    }

    void harvest(int tx, int ty) {
        Tile& t = w.at(tx, ty);
        int type = t.tree;
        t.fg = T_AIR; t.tree = 0; t.age = 0;
        au.play(S_HARVEST, 0.9f);
        burst(tx + 0.5f, ty + 0.5f, 90, 190, 70, 14, 4.f);
        int n = 1 + (int)(frand() * 3);
        dropItem(tx + 0.5f, ty + 0.5f, type, n);
        int g1 = 2 + (int)(frand() * 4), g2 = 1 + (int)(frand() * 3);
        dropItem(tx + 0.4f, ty + 0.5f, -1, g1);
        dropItem(tx + 0.6f, ty + 0.5f, -1, g2);
        if (frand() < 0.35f) dropItem(tx + 0.5f, ty + 0.4f, 100 + type, 1);
        spawnText(tx + 0.5f, ty - 0.2f, "HARVESTED!", 140, 255, 120);
    }

    void punch(int tx, int ty) {
        Tile& t = w.at(tx, ty);
        if (t.fg == T_AIR) return;
        if (t.fg == T_BEDROCK || t.fg == T_DOOR) {
            au.play(S_DENY, 0.5f);
            spawnText(tx + 0.5f, ty, "TOO HARD", 255, 200, 90);
            return;
        }
        if (t.fg == T_TREE) {
            if (t.age >= TREE_TIME) harvest(tx, ty);
            else {
                au.play(S_DENY, 0.5f);
                spawnText(tx + 0.5f, ty, "NOT READY", 255, 220, 120);
            }
            return;
        }
        t.dmg++; t.dmgT = 0;
        au.play(S_PUNCH, 0.8f, 0.9f + frand() * 0.3f);
        burst(tx + 0.5f, ty + 0.5f, TCOL[t.fg][0], TCOL[t.fg][1], TCOL[t.fg][2], 3, 2.5f);
        if (t.dmg >= HARD[t.fg]) breakBlock(tx, ty);
    }

    bool overlapsPlayer(int tx, int ty) {
        return tx + 1 > p.x - PHW && tx < p.x + PHW && ty + 1 > p.y - PH && ty < p.y;
    }

    void act(int tx, int ty) {
        if (!w.in(tx, ty)) return;
        float dx = tx + 0.5f - p.x, dy = ty + 0.5f - (p.y - 0.7f);
        if (dx * dx + dy * dy > 2.7f * 2.7f) return;
        p.face = dx < 0 ? -1 : 1;
        Slot& it = inv[sel];
        Tile& t = w.at(tx, ty);
        if (it.id == 0) {
            p.punchT = 0.18f;
            actCd = 0.22f;
            punch(tx, ty);
            return;
        }
        actCd = 0.14f;
        if (t.fg != T_AIR) {
            au.play(S_DENY, 0.4f);
            return;
        }
        if (it.id < 100) {
            bool sol = it.id != T_LAVA;
            if (sol && overlapsPlayer(tx, ty)) { au.play(S_DENY, 0.4f); return; }
            t.fg = (uint8_t)it.id; t.tree = 0; t.dmg = 0;
            au.play(S_PLACE, 0.8f, 0.95f + frand() * 0.1f);
            burst(tx + 0.5f, ty + 0.5f, TCOL[it.id][0], TCOL[it.id][1], TCOL[it.id][2], 4, 2.f);
            useOne();
        } else {
            int type = it.id - 100;
            if (!solid(tx, ty + 1) || type == T_LAVA) { au.play(S_DENY, 0.4f); spawnText(tx + 0.5f, ty, "NEEDS GROUND", 255, 200, 90); return; }
            t.fg = T_TREE; t.tree = (uint8_t)type; t.age = 0; t.dmg = 0;
            au.play(S_PLANT, 0.8f);
            burst(tx + 0.5f, ty + 0.8f, 90, 170, 60, 8, 2.5f);
            useOne();
        }
    }

    void sendChat() {
        std::string m = chatBuf;
        chatBuf.clear(); chatOpen = false;
        SDL_StopTextInput();
        if (m.empty()) return;
        if (m[0] == '/') {
            std::string c = upper(m);
            if (c == "/RESPAWN") { p.x = w.doorX + 0.5f; p.y = w.doorY + 1.f - 0.001f; p.vx = p.vy = 0; say("RESPAWNED AT THE DOOR."); }
            else if (c == "/SAVE") { saveAll(); say("WORLD SAVED."); }
            else if (c == "/HELP") { say("COMMANDS: /RESPAWN /SAVE /HELP"); say("A/D MOVE  SPACE JUMP  CLICK PUNCH OR PLACE  1-0 SELECT"); }
            else say("UNKNOWN COMMAND. TYPE /HELP");
            return;
        }
        p.bubble = m; p.bubbleT = 4.f;
        say("YOU: " + m);
        au.play(S_CHAT, 0.6f);
    }

    void updatePlay(float dt) {
        const Uint8* k = SDL_GetKeyboardState(nullptr);
        float ax = 0;
        bool jump = false;
        if (!chatOpen) {
            if (k[SDL_SCANCODE_A] || k[SDL_SCANCODE_LEFT] || heldRole(1)) ax -= 1;
            if (k[SDL_SCANCODE_D] || k[SDL_SCANCODE_RIGHT] || heldRole(2)) ax += 1;
            jump = k[SDL_SCANCODE_SPACE] || k[SDL_SCANCODE_W] || k[SDL_SCANCODE_UP] || heldRole(3);
        }
        float target = ax * 7.f;
        float acc = ax != 0 ? (p.ground ? 55.f : 32.f) : (p.ground ? 70.f : 12.f);
        if (p.vx < target) p.vx = std::min(target, p.vx + acc * dt);
        else if (p.vx > target) p.vx = std::max(target, p.vx - acc * dt);
        if (ax != 0) p.face = ax > 0 ? 1 : -1;
        if (jump && !p.jumpHeld) p.jumpBuf = 0.12f;
        p.jumpHeld = jump;
        p.coyote = p.ground ? 0.09f : p.coyote - dt;
        p.jumpBuf -= dt;
        if (p.jumpBuf > 0 && p.coyote > 0) {
            p.vy = -14.5f; p.coyote = 0; p.jumpBuf = 0; p.ground = false;
            au.play(S_JUMP, 0.6f, 0.95f + frand() * 0.1f);
        }
        p.vy = std::min(22.f, p.vy + 42.f * dt);
        float impact = p.vy;
        bool was = p.ground;
        movePlayer(dt);
        if (!was && p.ground && impact > 9.f) au.play(S_LAND, 0.6f);
        if (p.ground) p.walkT += std::fabs(p.vx) * dt * 1.8f;
        int lx0 = (int)std::floor(p.x - PHW), lx1 = (int)std::floor(p.x + PHW), ly0 = (int)std::floor(p.y - PH), ly1 = (int)std::floor(p.y - 0.01f);
        bool lava = false;
        for (int ty = ly0; ty <= ly1; ty++)
            for (int tx = lx0; tx <= lx1; tx++)
                if (w.in(tx, ty) && w.at(tx, ty).fg == T_LAVA) lava = true;
        if (lava) die();

        actCd -= dt;
        if (p.punchT > 0) p.punchT -= dt;
        if (p.bubbleT > 0) p.bubbleT -= dt;
        int tp = ZOOM[S.zoom];
        if (mdownWorld && !chatOpen && actCd <= 0) {
            int qx = hasAct ? tmx : mx, qy = hasAct ? tmy : my;
            int tx = (int)std::floor((qx + ccx) / (float)tp), ty = (int)std::floor((qy + ccy) / (float)tp);
            act(tx, ty);
        }

        for (auto& t : w.t) {
            if (t.fg == T_TREE && t.age < TREE_TIME) t.age += dt;
            if (t.dmg) { t.dmgT += dt; if (t.dmgT > 4.f) t.dmg = 0; }
        }

        for (size_t i = 0; i < drops.size();) {
            Drop& d = drops[i];
            d.age += dt;
            d.vy = std::min(18.f, d.vy + 18.f * dt);
            float nx = d.x + d.vx * dt;
            if (solid((int)std::floor(nx + (d.vx > 0 ? 0.15f : -0.15f)), (int)std::floor(d.y - 0.15f))) d.vx = -d.vx * 0.3f;
            else d.x = nx;
            d.y += d.vy * dt;
            int ty = (int)std::floor(d.y);
            if (solid((int)std::floor(d.x), ty)) {
                d.y = (float)ty;
                if (d.vy > 3.f) d.vy = -d.vy * 0.3f; else d.vy = 0;
                d.vx *= 0.85f;
            }
            float ddx = p.x - d.x, ddy = (p.y - 0.7f) - (d.y - 0.15f);
            float dist = std::sqrt(ddx * ddx + ddy * ddy);
            bool take = false;
            if (d.age > 0.35f) {
                if (d.item == -1 && dist < 2.2f) { d.x += ddx / (dist + 0.01f) * 7.f * dt; d.y += ddy / (dist + 0.01f) * 7.f * dt; }
                if (dist < 0.8f && (d.item == -1 || canAdd(d.item))) take = true;
            }
            if (take) {
                if (d.item == -1) {
                    gems += d.count;
                    au.play(S_GEM, 0.6f, 0.95f + frand() * 0.2f);
                    spawnText(p.x, p.y - 1.7f, "+" + std::to_string(d.count) + " GEMS", 120, 230, 255);
                } else {
                    addItem(d.item, d.count);
                    au.play(S_PICK, 0.6f);
                }
                drops.erase(drops.begin() + i);
            } else i++;
        }

        for (size_t i = 0; i < parts.size();) {
            Part& q = parts[i];
            q.life -= dt; q.vy += 14.f * dt; q.x += q.vx * dt; q.y += q.vy * dt;
            if (q.life <= 0) parts.erase(parts.begin() + i); else i++;
        }
        for (size_t i = 0; i < ftexts.size();) {
            ftexts[i].life -= dt; ftexts[i].y -= 0.8f * dt;
            if (ftexts[i].life <= 0) ftexts.erase(ftexts.begin() + i); else i++;
        }
        for (size_t i = 0; i < chatLog.size();) {
            chatLog[i].life -= dt;
            if (chatLog[i].life <= 0) chatLog.erase(chatLog.begin() + i); else i++;
        }
        if (flash > 0) flash -= dt * 1.5f;
        if (shake > 0) shake -= dt;
        autosave += dt;
        if (autosave > 30.f) { autosave = 0; saveAll(); }

        float tx = p.x * tp - LW / 2.f, ty = (p.y - 0.7f) * tp - LH / 2.f;
        camX += (tx - camX) * std::min(1.f, dt * 8.f);
        camY += (ty - camY) * std::min(1.f, dt * 8.f);
        clampCam();
        float sh = shake > 0 ? shake * 14.f : 0.f;
        ccx = (int)lroundf(camX + nz() * sh);
        ccy = (int)lroundf(camY + nz() * sh);
    }

    void fillR(float x, float y, float wd, float ht, int r, int g, int b, int a = 255) {
        SDL_SetRenderDrawColor(ren, (Uint8)clampi(r, 0, 255), (Uint8)clampi(g, 0, 255), (Uint8)clampi(b, 0, 255), (Uint8)clampi(a, 0, 255));
        int x0 = (int)lroundf(x), y0 = (int)lroundf(y), x1 = (int)lroundf(x + wd), y1 = (int)lroundf(y + ht);
        SDL_Rect q{x0, y0, std::max(1, x1 - x0), std::max(1, y1 - y0)};
        SDL_RenderFillRect(ren, &q);
    }

    int tw(const std::string& s, int sc) { return s.empty() ? 0 : (int)s.size() * 4 * sc - sc; }

    void rawText(int x, int y, const std::string& s, int sc, int r, int g, int b, int a) {
        int cx = x;
        for (char ch : s) {
            char c = (char)std::toupper((unsigned char)ch);
            const char* pos = c ? std::strchr(GCH, c) : nullptr;
            if (pos) {
                const char* rw = GR[pos - GCH];
                for (int row = 0; row < 5; row++) {
                    int bits = rw[row] - '0';
                    for (int col = 0; col < 3; col++)
                        if ((bits >> (2 - col)) & 1) fillR((float)(cx + col * sc), (float)(y + row * sc), (float)sc, (float)sc, r, g, b, a);
                }
            }
            cx += 4 * sc;
        }
    }

    void text(int x, int y, const std::string& s, int sc, int r, int g, int b, int a = 255) {
        rawText(x + std::max(1, sc / 2), y + std::max(1, sc / 2), s, sc, 0, 0, 0, a * 3 / 5);
        rawText(x, y, s, sc, r, g, b, a);
    }
    void textC(int cx, int y, const std::string& s, int sc, int r, int g, int b, int a = 255) { text(cx - tw(s, sc) / 2, y, s, sc, r, g, b, a); }

    void copyTile(int type, int variant, float dx, float dy, float size, int alpha = 255) {
        SDL_Rect src{variant * 16, type * 16, 16, 16};
        int x0 = (int)lroundf(dx), y0 = (int)lroundf(dy), x1 = (int)lroundf(dx + size), y1 = (int)lroundf(dy + size);
        SDL_Rect dst{x0, y0, x1 - x0, y1 - y0};
        SDL_SetTextureAlphaMod(tiles, (Uint8)alpha);
        SDL_RenderCopy(ren, tiles, &src, &dst);
        SDL_SetTextureAlphaMod(tiles, 255);
    }

    void drawGem(float x, float y, float size, int value) {
        int r = 80, g = 220, b = 255;
        if (value >= 4) { r = 255; g = 90; b = 130; }
        else if (value >= 2) { r = 100; g = 240; b = 120; }
        int rows = std::max(4, (int)size);
        int hs = rows / 2;
        for (int i = 0; i < rows; i++) {
            int d = i < hs ? i : rows - 1 - i;
            float wd = (float)(2 * d + 2) * size / rows;
            fillR(x + size / 2 - wd / 2, y + i * size / rows, wd, size / rows + 1, r, g, b);
        }
        fillR(x + size * 0.38f, y + size * 0.18f, size * 0.12f, size * 0.12f, 255, 255, 255, 220);
    }

    void drawSeedIcon(int type, float x, float y, float size) {
        fillR(x + size * 0.3f, y + size * 0.42f, size * 0.4f, size * 0.4f, TCOL[type][0], TCOL[type][1], TCOL[type][2]);
        fillR(x + size * 0.3f, y + size * 0.42f, size * 0.4f, size * 0.08f, 255, 255, 255, 80);
        fillR(x + size * 0.46f, y + size * 0.2f, size * 0.08f, size * 0.24f, 60, 130, 40);
        fillR(x + size * 0.26f, y + size * 0.16f, size * 0.22f, size * 0.12f, 90, 190, 70);
        fillR(x + size * 0.54f, y + size * 0.1f, size * 0.22f, size * 0.12f, 90, 190, 70);
    }

    void drawIcon(int id, float x, float y, float size) {
        if (id == 0) {
            fillR(x + size * 0.2f, y + size * 0.3f, size * 0.6f, size * 0.45f, 245, 205, 165);
            for (int i = 1; i < 4; i++) fillR(x + size * (0.2f + i * 0.15f), y + size * 0.3f, std::max(1.f, size * 0.03f), size * 0.2f, 190, 150, 115);
            fillR(x + size * 0.2f, y + size * 0.7f, size * 0.6f, size * 0.08f, 200, 160, 125);
        } else if (id == -1) drawGem(x + size * 0.15f, y + size * 0.15f, size * 0.7f, 1);
        else if (id < 100) copyTile(id, 0, x + size * 0.1f, y + size * 0.1f, size * 0.8f);
        else drawSeedIcon(id - 100, x, y, size);
    }

    std::string itemName(int id) {
        if (id == 0) return "FIST";
        if (id < 100) return TNAME[id];
        return std::string(TNAME[id - 100]) + " SEED";
    }

    void drawSky() {
        for (int i = 0; i < 24; i++) {
            float f = i / 23.f;
            fillR(0, i * LH / 24.f, LW, LH / 24.f + 1, (int)(95 + 110 * f), (int)(170 + 65 * f), (int)(255 - 10 * f));
        }
        for (int dy = -40; dy <= 40; dy += 2) {
            float wd = std::sqrt(1600.f - dy * dy) * 2.f;
            fillR(1060 - wd / 2, 100 + dy, wd, 2, 255, 240, 150, 230);
        }
    }

    void drawClouds(float offX, float offY) {
        for (auto& c : clouds) {
            float cx = std::fmod(c.x + (float)time * c.sp - offX, (float)(LW + 500));
            if (cx < 0) cx += LW + 500;
            cx -= 250;
            float cy = c.y - offY, s = c.s;
            fillR(cx, cy + 14 * s, 120 * s, 26 * s, 255, 255, 255, 215);
            fillR(cx + 18 * s, cy, 70 * s, 26 * s, 255, 255, 255, 215);
            fillR(cx + 60 * s, cy + 6 * s, 60 * s, 24 * s, 255, 255, 255, 215);
        }
    }

    void drawHills(float offX, float baseY, int layer, float sc) {
        for (int x = 0; x < LW; x += 8) {
            float wx = x + offX;
            float h = (60 + 40 * std::sin(wx * 0.004f + layer * 2.f) + 25 * std::sin(wx * 0.011f + layer)) * sc;
            if (layer == 0) fillR((float)x, baseY - h, 8, h + 200, 120, 185, 150);
            else fillR((float)x, baseY - h * 0.7f, 8, h * 0.7f + 200, 85, 160, 100);
        }
    }

    void drawMenuBg() {
        drawSky();
        drawClouds((float)time * 0, 0);
        drawHills((float)time * 6, LH - 150.f, 0, 1.f);
        drawHills((float)time * 12 + 300, LH - 110.f, 1, 1.f);
        for (int x = 0; x < LW; x += 48) {
            copyTile(T_GRASS, (x / 48) & 3, (float)x, LH - 96.f, 48);
            copyTile(T_DIRT, (x / 48 + 1) & 3, (float)x, LH - 48.f, 48);
        }
    }

    void drawLogo(int y) {
        const std::string t = "BLOCKBLOOM";
        int sc = 10, x = LW / 2 - tw(t, sc) / 2;
        for (size_t i = 0; i < t.size(); i++) {
            int yy = y + (int)(std::sin(time * 2.5 + i * 0.6) * 8);
            std::string ch(1, t[i]);
            rawText(x + (int)i * 4 * sc + 6, yy + 6, ch, sc, 40, 25, 10, 200);
            rawText(x + (int)i * 4 * sc, yy, ch, sc, 255, 190 + (int)(i * 6), 60, 255);
        }
        textC(LW / 2, y + 80, "A SANDBOX OF PUNCHING AND PLANTING", 2, 255, 255, 255);
    }

    SDL_Rect mrect(int i, int n) {
        int y0 = std::max(120, (LH - n * 58) / 2 + 30);
        return {340, y0 + i * 58, 600, 50};
    }

    bool inRect(const SDL_Rect& r, int x, int y) { return x >= r.x && x < r.x + r.w && y >= r.y && y < r.y + r.h; }

    void setSlider(MItem& it, const SDL_Rect& r) {
        float f = (mx - (r.x + 300)) / 250.f;
        int v = (int)std::lround(std::max(0.f, std::min(1.f, f)) * (it.hi - it.lo) / 5.f) * 5 + it.lo;
        if (v != *it.v) { *it.v = v; if (it.act) it.act(); }
    }

    void adjust(MItem& it, int dir) {
        if (it.kind == 1) { *it.v = clampi(*it.v + dir * 5, it.lo, it.hi); }
        else if (it.kind == 2) *it.v = !*it.v;
        else if (it.kind == 3) *it.v = ((*it.v + dir) % (it.hi + 1) + it.hi + 1) % (it.hi + 1);
        if (it.kind != 0) { au.play(S_CLICK, 0.5f); if (it.act) it.act(); }
    }

    void escape() {
        if (st == ST_SETTINGS || st == ST_GRAPHICS) { S.save(); st = from; }
        else if (st == ST_PAUSE) st = ST_PLAY;
        else if (st == ST_WORLD) { st = ST_MENU; SDL_StopTextInput(); }
    }

    void menuEvent(Menu& m, const SDL_Event& e) {
        int n = (int)m.items.size();
        if (e.type == SDL_MOUSEMOTION) {
            if (drag >= 0 && drag < n) setSlider(m.items[drag], mrect(drag, n));
            else for (int i = 0; i < n; i++) if (inRect(mrect(i, n), mx, my)) m.sel = i;
        } else if (e.type == SDL_MOUSEBUTTONDOWN && e.button.button == SDL_BUTTON_LEFT) {
            for (int i = 0; i < n; i++) {
                SDL_Rect r = mrect(i, n);
                if (!inRect(r, mx, my)) continue;
                m.sel = i;
                MItem& it = m.items[i];
                if (it.kind == 0) { au.play(S_CLICK, 0.7f); if (it.act) it.act(); }
                else if (it.kind == 1) { drag = i; setSlider(it, r); }
                else adjust(it, 1);
                break;
            }
        } else if (e.type == SDL_MOUSEBUTTONUP) drag = -1;
        else if (e.type == SDL_KEYDOWN) {
            SDL_Keycode k = e.key.keysym.sym;
            MItem& it = m.items[m.sel];
            if (k == SDLK_UP) { m.sel = (m.sel + n - 1) % n; au.play(S_CLICK, 0.3f); }
            else if (k == SDLK_DOWN) { m.sel = (m.sel + 1) % n; au.play(S_CLICK, 0.3f); }
            else if (k == SDLK_LEFT) adjust(it, -1);
            else if (k == SDLK_RIGHT) adjust(it, 1);
            else if (k == SDLK_RETURN || k == SDLK_KP_ENTER || k == SDLK_SPACE) {
                if (it.kind == 0) { au.play(S_CLICK, 0.7f); if (it.act) it.act(); }
                else if (it.kind != 1) adjust(it, 1);
            } else if (k == SDLK_ESCAPE) escape();
        }
    }

    void menuDraw(Menu& m) {
        int n = (int)m.items.size();
        if (!m.title.empty()) textC(LW / 2, mrect(0, n).y - 62, m.title, 5, 255, 255, 255);
        for (int i = 0; i < n; i++) {
            SDL_Rect r = mrect(i, n);
            MItem& it = m.items[i];
            bool sel = i == m.sel;
            fillR((float)r.x, (float)r.y, (float)r.w, (float)r.h, sel ? 255 : 0, sel ? 255 : 0, sel ? 255 : 0, sel ? 80 : 110);
            fillR((float)r.x, (float)r.y, (float)r.w, 3, sel ? 255 : 230, sel ? 220 : 230, sel ? 90 : 230, sel ? 255 : 120);
            fillR((float)r.x, (float)(r.y + r.h - 3), (float)r.w, 3, 0, 0, 0, 120);
            int cr = sel ? 255 : 235, cg = sel ? 225 : 235, cb = sel ? 110 : 235;
            if (it.kind == 0) textC(r.x + r.w / 2, r.y + 17, it.label, 3, cr, cg, cb);
            else {
                text(r.x + 18, r.y + 17, it.label, 3, cr, cg, cb);
                if (it.kind == 1) {
                    float f = (*it.v - it.lo) / (float)(it.hi - it.lo);
                    fillR((float)(r.x + 300), (float)(r.y + 18), 250, 14, 0, 0, 0, 160);
                    fillR((float)(r.x + 300), (float)(r.y + 18), 250 * f, 14, 110, 220, 90);
                    fillR(r.x + 300 + 250 * f - 5, (float)(r.y + 12), 10, 26, 255, 255, 255);
                    text(r.x + 560, r.y + 19, std::to_string(*it.v), 2, 255, 255, 255);
                } else if (it.kind == 2) {
                    std::string s = *it.v ? "ON" : "OFF";
                    text(r.x + r.w - 18 - tw(s, 3), r.y + 17, s, 3, *it.v ? 120 : 255, *it.v ? 240 : 110, *it.v ? 110 : 100);
                } else {
                    std::string s = "< " + it.opts[*it.v] + " >";
                    text(r.x + r.w - 18 - tw(s, 3), r.y + 17, s, 3, 255, 230, 140);
                }
            }
        }
    }

    int wsOff() { return touch ? -170 : 0; }
    SDL_Rect wbtn(int i) { return {LW / 2 - 300 + i * 310, 470 + wsOff(), 290, 56}; }

    void drawWorldSelect() {
        int o = wsOff();
        fillR(LW / 2 - 340, 200 + o, 680, 360, 0, 0, 0, 140);
        textC(LW / 2, 230 + o, "ENTER WORLD NAME", 4, 255, 255, 255);
        fillR(LW / 2 - 280, 310 + o, 560, 70, 255, 255, 255, 235);
        fillR(LW / 2 - 280, 310 + o, 560, 4, 90, 90, 100);
        std::string s = wname + (((int)(time * 2)) % 2 == 0 ? "_" : "");
        text(LW / 2 - 262, 330 + o, s, 5, 40, 40, 60);
        textC(LW / 2, 400 + o, "LETTERS AND NUMBERS ONLY. NEW NAMES MAKE NEW WORLDS.", 2, 230, 230, 230);
        const char* lb[2] = {"ENTER WORLD", "BACK"};
        for (int i = 0; i < 2; i++) {
            SDL_Rect r = wbtn(i);
            bool hv = inRect(r, mx, my);
            fillR((float)r.x, (float)r.y, (float)r.w, (float)r.h, hv ? 255 : 0, hv ? 255 : 0, hv ? 255 : 0, hv ? 80 : 110);
            fillR((float)r.x, (float)r.y, (float)r.w, 3, hv ? 255 : 230, hv ? 220 : 230, hv ? 90 : 230);
            textC(r.x + r.w / 2, r.y + 20, lb[i], 3, hv ? 255 : 235, hv ? 225 : 235, hv ? 110 : 235);
        }
    }

    void drawLoading() {
        drawSky();
        drawClouds(0, 0);
        drawHills((float)time * 8, LH - 150.f, 0, 1.f);
        drawHills((float)time * 14 + 300, LH - 110.f, 1, 1.f);
        drawLogo(170);
        if (tiles) {
            int ids[5] = {T_DIRT, T_GRASS, T_ROCK, T_WOOD, T_GLASS};
            for (int i = 0; i < 5; i++) {
                float yy = 400 - std::fabs((float)std::sin(time * 4 + i * 0.7)) * 40;
                copyTile(ids[i], 0, LW / 2 - 140.f + i * 60, yy, 48);
            }
        }
        float tp = std::min(taskI / (float)tasks.size(), loadT / 2.6f);
        fillR(340, 560, 600, 26, 0, 0, 0, 150);
        fillR(344, 564, 592 * tp, 18, 120, 225, 90);
        fillR(344, 564, 592 * tp, 6, 190, 255, 160);
        textC(LW / 2, 528, "LOADING... " + std::to_string((int)(tp * 100)) + "%", 3, 255, 255, 255);
        static const char* tips[4] = {"PUNCH BLOCKS TO COLLECT GEMS AND SEEDS", "PLANT SEEDS ON SOLID GROUND AND WAIT FOR TREES",
                                      "STAY AWAY FROM LAVA", "PRESS ENTER TO CHAT WITH THE WORLD"};
        textC(LW / 2, 610, tips[((int)(loadT / 1.2f)) % 4], 2, 255, 255, 255);
    }

    void drawTree(const Tile& t, float dx, float dy, float tp) {
        float u = tp / 16.f, f = std::min(1.f, t.age / TREE_TIME);
        auto R = [&](float x, float y, float wd, float ht, int r, int g, int b) { fillR(dx + x * u, dy + y * u, wd * u, ht * u, r, g, b); };
        if (f < 0.33f) {
            R(7, 10, 2, 6, 60, 120, 40); R(4, 8, 4, 2, 90, 190, 70); R(8, 6, 4, 2, 90, 190, 70);
        } else if (f < 0.66f) {
            R(7, 6, 2, 10, 60, 120, 40); R(3, 6, 5, 3, 90, 190, 70); R(8, 4, 5, 3, 90, 190, 70); R(5, 2, 6, 3, 110, 205, 85);
        } else {
            R(7, 4, 2, 12, 60, 120, 40); R(2, 6, 6, 4, 80, 180, 65); R(8, 6, 6, 4, 80, 180, 65); R(4, 1, 8, 5, 105, 205, 85);
            if (f >= 1.f) {
                int c0 = TCOL[t.tree][0], c1 = TCOL[t.tree][1], c2 = TCOL[t.tree][2];
                R(3, 7, 3, 3, c0, c1, c2); R(10, 7, 3, 3, c0, c1, c2); R(6, 2, 3, 3, c0, c1, c2);
                float tw2 = 0.5f + 0.5f * (float)std::sin(time * 5);
                fillR(dx + 12 * u, dy + 3 * u, u, u, 255, 255, 255, (int)(200 * tw2));
            }
        }
    }

    void drawPlayer(float tp, float px, float py) {
        auto R = [&](float x, float y, float wd, float ht, int r, int g, int b) {
            float fx = p.face > 0 ? x : -x - wd;
            fillR(px + fx * tp, py + y * tp, wd * tp, ht * tp, r, g, b);
        };
        float ls = p.ground ? (float)std::sin(p.walkT * 3.f) * 0.1f : 0.08f;
        R(-0.22f + ls, -0.45f, 0.2f, 0.45f, 40, 60, 140);
        R(0.02f - ls, -0.45f, 0.2f, 0.45f, 40, 60, 140);
        R(-0.24f + ls, -0.06f, 0.24f, 0.06f, 50, 40, 40);
        R(0.02f - ls, -0.06f, 0.24f, 0.06f, 50, 40, 40);
        R(-0.28f, -0.95f, 0.56f, 0.52f, 220, 70, 60);
        R(-0.28f, -0.5f, 0.56f, 0.07f, 150, 40, 40);
        R(-0.25f, -1.45f, 0.5f, 0.5f, 245, 205, 165);
        R(-0.27f, -1.48f, 0.54f, 0.17f, 70, 45, 25);
        R(-0.27f, -1.35f, 0.1f, 0.25f, 70, 45, 25);
        R(0.05f, -1.25f, 0.12f, 0.12f, 30, 30, 30);
        R(0.0f, -1.05f, 0.2f, 0.04f, 190, 110, 100);
        if (p.punchT > 0) {
            R(0.05f, -0.88f, 0.45f, 0.14f, 245, 205, 165);
            R(0.5f, -0.92f, 0.2f, 0.22f, 245, 205, 165);
        } else {
            R(0.28f, -0.95f, 0.1f, 0.42f, 245, 205, 165);
        }
        R(-0.38f, -0.95f, 0.1f, 0.42f, 245, 205, 165);
    }

    void drawWorld() {
        int tp = ZOOM[S.zoom];
        float sc = tp / 32.f;
        drawSky();
        if (S.clouds) drawClouds(ccx * 0.2f, ccy * 0.25f);
        float base = 23.f * tp - ccy;
        drawHills(ccx * 0.15f, base, 0, sc);
        drawHills(ccx * 0.35f + 300, base + 8, 1, sc);
        int x0 = std::max(0, ccx / tp), x1 = std::min(WW - 1, (ccx + LW) / tp);
        int y0 = std::max(0, ccy / tp), y1 = std::min(WH - 1, (ccy + LH) / tp);
        for (int ty = y0; ty <= y1; ty++)
            for (int tx = x0; tx <= x1; tx++) {
                Tile& t = w.at(tx, ty);
                float dx = (float)(tx * tp - ccx), dy = (float)(ty * tp - ccy);
                bool opaque = t.fg == T_DIRT || t.fg == T_GRASS || t.fg == T_ROCK || t.fg == T_BEDROCK || t.fg == T_WOOD;
                if (ty > w.surf[tx] && !opaque) copyTile(T_COUNT, (int)(hash2(tx, ty) & 3), dx, dy, (float)tp);
                if (t.fg == T_AIR) continue;
                if (t.fg == T_TREE) { drawTree(t, dx, dy, (float)tp); continue; }
                int var = t.fg == T_LAVA ? (((int)(time * 6)) + tx * 3 + ty) & 3 : (int)(hash2(tx, ty) & 3);
                copyTile(t.fg, var, dx, dy, (float)tp);
                if (t.dmg > 0) {
                    int n = 1 + t.dmg * 7 / std::max(1, HARD[t.fg]);
                    float u = tp / 16.f;
                    for (int i = 0; i < n; i++) {
                        uint32_t h = hash2(tx, ty, i);
                        fillR(dx + (float)(h % 14) * u, dy + (float)((h >> 8) % 14) * u, u * 2, u * 2, 0, 0, 0, 150);
                    }
                }
            }
        for (auto& d : drops) {
            float dx = d.x * tp - ccx, dy = (d.y - 0.35f + (float)std::sin(time * 4 + d.x * 3) * 0.04f) * tp - ccy;
            if (d.item == -1) drawGem(dx - tp * 0.15f, dy, tp * 0.32f, d.count);
            else {
                drawIcon(d.item, dx - tp * 0.22f, dy - tp * 0.05f, tp * 0.45f);
                if (d.count > 1) text((int)dx + 4, (int)dy + 8, std::to_string(d.count), 1, 255, 255, 255);
            }
        }
        float px = p.x * tp - ccx, py = p.y * tp - ccy;
        drawPlayer((float)tp, px, py);
        if (p.bubbleT > 0 && S.chat) {
            std::string b = p.bubble.substr(0, 30);
            int bw = tw(b, 2) + 16, bx = (int)px - bw / 2, by = (int)(py - 1.45f * tp - 38);
            fillR((float)bx, (float)by, (float)bw, 26, 255, 255, 255, 235);
            fillR(px - 4, (float)(by + 26), 8, 6, 255, 255, 255, 235);
            rawText(bx + 8, by + 8, b, 2, 30, 30, 50, 255);
        }
        for (auto& q : parts) {
            float a = std::max(0.f, q.life / q.max);
            fillR(q.x * tp - ccx, q.y * tp - ccy, q.size * tp, q.size * tp, q.r, q.g, q.b, (int)(255 * std::min(1.f, a * 1.5f)));
        }
        for (auto& f : ftexts) textC((int)(f.x * tp - ccx), (int)(f.y * tp - ccy), f.s, 2, f.r, f.g, f.b, (int)(255 * std::min(1.f, f.life * 2)));
        if (flash > 0) fillR(0, 0, LW, LH, 255, 40, 20, (int)(120 * std::min(1.f, flash)));
        drawHud();
    }

    SDL_Rect slotRect(int i) {
        int x0 = (LW - (MAXSLOTS * 58 - 6)) / 2;
        return {x0 + i * 58, LH - 66, 52, 52};
    }

    void drawArrow(float cx, float cy, int dir) {
        const float s = 24.f;
        for (float r = -s; r <= s; r += 2.f) {
            float a = std::fabs(r);
            if (dir == 0) fillR(cx - s / 2 + a, cy + r, s - a, 2, 255, 255, 255, 220);
            else if (dir == 1) fillR(cx - s / 2, cy + r, s - a, 2, 255, 255, 255, 220);
            else fillR(cx - (r + s) / 2, cy + r, r + s + 2, 2, 255, 255, 255, 220);
        }
    }

    void drawHud() {
        fillR(12, 12, 150, 40, 0, 0, 0, 130);
        drawGem(22, 20, 24, 1);
        text(54, 24, std::to_string(gems), 3, 255, 255, 255);
        std::string wn = "WORLD: " + wname;
        fillR(LW / 2.f - tw(wn, 3) / 2.f - 14, 12, (float)tw(wn, 3) + 28, 40, 0, 0, 0, 130);
        textC(LW / 2, 24, wn, 3, 255, 255, 255);
        if (S.showFps) text(LW - 140, touch ? 70 : 14, "FPS " + std::to_string((int)fps), 2, 255, 255, 120);
        for (int i = 0; i < MAXSLOTS; i++) {
            SDL_Rect r = slotRect(i);
            bool has = i < (int)inv.size();
            bool sl = i == sel;
            fillR((float)r.x, (float)r.y, (float)r.w, (float)r.h, 0, 0, 0, 130);
            if (sl) {
                fillR((float)r.x - 3, (float)r.y - 3, r.w + 6.f, 3, 255, 220, 80);
                fillR((float)r.x - 3, (float)r.y + r.h, r.w + 6.f, 3, 255, 220, 80);
                fillR((float)r.x - 3, (float)r.y, 3, (float)r.h, 255, 220, 80);
                fillR((float)r.x + r.w, (float)r.y, 3, (float)r.h, 255, 220, 80);
            }
            if (i < 10) text(r.x + 4, r.y + 3, std::to_string((i + 1) % 10), 1, 220, 220, 220);
            if (has) {
                drawIcon(inv[i].id, (float)r.x + 2, (float)r.y + 2, 48);
                if (inv[i].id != 0) text(r.x + r.w - 4 - tw(std::to_string(inv[i].count), 2), r.y + r.h - 14, std::to_string(inv[i].count), 2, 255, 255, 255);
            }
        }
        if (sel < (int)inv.size()) textC(LW / 2, LH - 90, itemName(inv[sel].id), 2, 255, 240, 160);
        int y = touch ? 64 + (chatOpen ? 52 : 0) : LH - 130 - (int)chatLog.size() * 20;
        for (auto& c : chatLog) {
            int a = (int)(255 * std::min(1.f, c.life));
            fillR(12, (float)y - 2, (float)tw(c.s, 2) + 12, 18, 0, 0, 0, a / 2);
            text(18, y, c.s, 2, 255, 255, 255, a);
            y += 20;
        }
        if (chatOpen) {
            int cy = touch ? 64 : LH - 128;
            fillR(LW / 2.f - 360, (float)cy, 720, 40, 0, 0, 0, 190);
            std::string s = "> " + chatBuf + (((int)(time * 2)) % 2 == 0 ? "_" : "");
            text(LW / 2 - 348, cy + 10, s, 3, 255, 255, 255);
        }
        if (touch) {
            static const char* lb[5] = {"", "", "", "CHAT", "MENU"};
            for (int i = 0; i < 5; i++) {
                SDL_Rect r = btnRect(i);
                bool hv = i < 3 && heldRole(i + 1);
                fillR((float)r.x, (float)r.y, (float)r.w, (float)r.h, hv ? 255 : 0, hv ? 255 : 0, hv ? 255 : 0, hv ? 110 : 90);
                fillR((float)r.x, (float)r.y, (float)r.w, 3, 255, 255, 255, 140);
                if (i < 3) drawArrow(r.x + r.w / 2.f, r.y + r.h / 2.f, i);
                else textC(r.x + r.w / 2, r.y + 17, lb[i], 2, 255, 255, 255);
            }
        }
    }

    void playEvent(const SDL_Event& e) {
        if (e.type == SDL_FINGERDOWN) {
            int lx, ly;
            fingerPos(e.tfinger, lx, ly);
            for (int i = 0; i < MAXSLOTS; i++)
                if (inRect(slotRect(i), lx, ly)) {
                    if (i < (int)inv.size()) { sel = i; au.play(S_CLICK, 0.4f); }
                    return;
                }
            for (int i = 0; i < 5; i++)
                if (inRect(btnRect(i), lx, ly)) {
                    if (i < 3) fingers[e.tfinger.fingerId] = i + 1;
                    else if (i == 3) {
                        au.play(S_CLICK, 0.5f);
                        if (chatOpen) sendChat();
                        else { chatOpen = true; SDL_StartTextInput(); }
                    } else { au.play(S_CLICK, 0.5f); clearTouch(); st = ST_PAUSE; mPause.sel = 0; }
                    return;
                }
            if (!chatOpen && !hasAct) { hasAct = true; actFinger = e.tfinger.fingerId; tmx = lx; tmy = ly; mdownWorld = true; }
            return;
        }
        if (e.type == SDL_FINGERMOTION) {
            if (hasAct && e.tfinger.fingerId == actFinger) fingerPos(e.tfinger, tmx, tmy);
            return;
        }
        if (e.type == SDL_KEYDOWN) {
            SDL_Keycode k = e.key.keysym.sym;
            if (chatOpen) {
                if (k == SDLK_ESCAPE) { chatOpen = false; chatBuf.clear(); SDL_StopTextInput(); }
                else if (k == SDLK_RETURN || k == SDLK_KP_ENTER) sendChat();
                else if (k == SDLK_BACKSPACE && !chatBuf.empty()) chatBuf.pop_back();
                return;
            }
            if (e.key.repeat) return;
            if (k == SDLK_ESCAPE) { st = ST_PAUSE; clearTouch(); mPause.sel = 0; }
            else if (k == SDLK_RETURN || k == SDLK_KP_ENTER) { chatOpen = true; SDL_StartTextInput(); }
            else if (k == SDLK_F3) S.showFps ^= 1;
            else if (k >= SDLK_1 && k <= SDLK_9) { int i = (int)(k - SDLK_1); if (i < (int)inv.size()) sel = i; }
            else if (k == SDLK_0) { if (9 < (int)inv.size()) sel = 9; }
        } else if (e.type == SDL_TEXTINPUT) {
            if (chatOpen) {
                for (const char* c = e.text.text; *c; c++)
                    if (*c >= 32 && *c < 127 && chatBuf.size() < 60) chatBuf.push_back(*c);
            }
        } else if (e.type == SDL_MOUSEBUTTONDOWN && e.button.button == SDL_BUTTON_LEFT) {
            for (int i = 0; i < MAXSLOTS; i++)
                if (inRect(slotRect(i), mx, my)) {
                    if (i < (int)inv.size()) { sel = i; au.play(S_CLICK, 0.4f); }
                    return;
                }
            if (!chatOpen) mdownWorld = true;
        } else if (e.type == SDL_MOUSEBUTTONUP) mdownWorld = false;
        else if (e.type == SDL_MOUSEWHEEL && !chatOpen) {
            int n = (int)inv.size();
            sel = ((sel - e.wheel.y) % n + n) % n;
        }
    }

    void worldEvent(const SDL_Event& e) {
        if (e.type == SDL_KEYDOWN) {
            SDL_Keycode k = e.key.keysym.sym;
            if (k == SDLK_ESCAPE) escape();
            else if (k == SDLK_RETURN || k == SDLK_KP_ENTER) { au.play(S_CLICK, 0.7f); enterWorld(wname); }
            else if (k == SDLK_BACKSPACE && !wname.empty()) wname.pop_back();
        } else if (e.type == SDL_TEXTINPUT) {
            for (const char* c = e.text.text; *c; c++) {
                char u = (char)std::toupper((unsigned char)*c);
                if (std::isalnum((unsigned char)u) && wname.size() < 16) wname.push_back(u);
            }
        } else if (e.type == SDL_MOUSEBUTTONDOWN && e.button.button == SDL_BUTTON_LEFT) {
            if (inRect(SDL_Rect{LW / 2 - 280, 310 + wsOff(), 560, 70}, mx, my)) SDL_StartTextInput();
            else if (inRect(wbtn(0), mx, my)) { au.play(S_CLICK, 0.7f); enterWorld(wname); }
            else if (inRect(wbtn(1), mx, my)) { au.play(S_CLICK, 0.7f); escape(); }
        }
    }

    void handle(const SDL_Event& ev) {
        SDL_Event e = ev;
        if (e.type == SDL_KEYDOWN && e.key.keysym.sym == SDLK_AC_BACK) e.key.keysym.sym = SDLK_ESCAPE;
        if (e.type == SDL_QUIT) { quit(); return; }
        if (e.type == SDL_APP_WILLENTERBACKGROUND) {
            if (st == ST_PLAY || st == ST_PAUSE) saveAll();
            S.save();
            return;
        }
        bool emu = (e.type == SDL_MOUSEMOTION && e.motion.which == SDL_TOUCH_MOUSEID) ||
                   ((e.type == SDL_MOUSEBUTTONDOWN || e.type == SDL_MOUSEBUTTONUP) && e.button.which == SDL_TOUCH_MOUSEID);
        if (emu && st == ST_PLAY) return;
        if (e.type == SDL_FINGERDOWN) touch = true;
        if (e.type == SDL_FINGERUP) {
            fingers.erase(e.tfinger.fingerId);
            if (hasAct && e.tfinger.fingerId == actFinger) { hasAct = false; mdownWorld = false; }
        }
        if (e.type == SDL_MOUSEMOTION) { mx = e.motion.x; my = e.motion.y; }
        if (e.type == SDL_MOUSEBUTTONDOWN || e.type == SDL_MOUSEBUTTONUP) { mx = e.button.x; my = e.button.y; }
        if (e.type == SDL_KEYDOWN && e.key.keysym.sym == SDLK_F11 && !e.key.repeat) { S.fullscreen ^= 1; applyGraphics(); S.save(); return; }
        switch (st) {
            case ST_LOADING: break;
            case ST_MENU: menuEvent(mMain, e); break;
            case ST_SETTINGS: menuEvent(mSet, e); break;
            case ST_GRAPHICS: menuEvent(mGfx, e); break;
            case ST_PAUSE: menuEvent(mPause, e); break;
            case ST_WORLD: worldEvent(e); break;
            case ST_PLAY: playEvent(e); break;
        }
    }

    void update(float dt) {
        if (st == ST_LOADING) {
            loadT += dt;
            if (taskI < tasks.size()) { tasks[taskI](); taskI++; }
            else if (loadT > 2.6f) {
                st = ST_MENU;
                if (!musicOn) { au.play(S_MUSIC, 1.f, 1.f, true, true); musicOn = true; }
                au.play(S_ENTER, 0.7f);
            }
        } else if (st == ST_PLAY) updatePlay(dt);
    }

    void draw() {
        SDL_SetRenderDrawColor(ren, 0, 0, 0, 255);
        SDL_RenderClear(ren);
        switch (st) {
            case ST_LOADING: drawLoading(); break;
            case ST_MENU: drawMenuBg(); drawLogo(80); menuDraw(mMain); break;
            case ST_SETTINGS: drawMenuBg(); menuDraw(mSet); break;
            case ST_GRAPHICS: drawMenuBg(); menuDraw(mGfx); break;
            case ST_WORLD: drawMenuBg(); if (!touch) drawLogo(60); drawWorldSelect(); break;
            case ST_PLAY: drawWorld(); break;
            case ST_PAUSE: drawWorld(); fillR(0, 0, LW, LH, 0, 0, 0, 150); menuDraw(mPause); break;
        }
        if (S.showFps && st != ST_PLAY && st != ST_PAUSE) text(LW - 140, 14, "FPS " + std::to_string((int)fps), 2, 255, 255, 120);
        SDL_RenderPresent(ren);
    }

    void run() {
        Uint64 last = SDL_GetPerformanceCounter();
        double freq = (double)SDL_GetPerformanceFrequency();
        while (running) {
            Uint64 now = SDL_GetPerformanceCounter();
            float dt = (float)((now - last) / freq);
            last = now;
            if (dt < 0.0001f) dt = 0.0001f;
            fps = fps * 0.95f + (1.f / dt) * 0.05f;
            if (dt > 0.033f) dt = 0.033f;
            time += dt;
            SDL_Event e;
            while (SDL_PollEvent(&e)) handle(e);
            update(dt);
            draw();
            if (!S.vsync && S.fpsLimit < 3) {
                static const int lim[3] = {30, 60, 120};
                double ms = (SDL_GetPerformanceCounter() - now) * 1000.0 / freq, want = 1000.0 / lim[S.fpsLimit];
                if (ms < want) SDL_Delay((Uint32)(want - ms));
            }
        }
    }

    void shutdown() {
        if (au.dev) SDL_CloseAudioDevice(au.dev);
        if (tiles) SDL_DestroyTexture(tiles);
        if (ren) SDL_DestroyRenderer(ren);
        if (win) SDL_DestroyWindow(win);
        SDL_Quit();
    }
};

int main(int, char**) {
    Game g;
    if (!g.init()) {
        std::fprintf(stderr, "init failed: %s\n", SDL_GetError());
        return 1;
    }
    g.run();
    g.shutdown();
    return 0;
}
